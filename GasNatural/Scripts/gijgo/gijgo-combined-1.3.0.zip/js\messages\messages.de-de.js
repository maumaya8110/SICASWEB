gj.dialog.messages['de-de'] = {
    Close: 'Schlie&szlig;en',
    DefaultTitle: 'Dialog'
};
gj.grid.messages['de-de'] = {
    First: 'Erste',
    Previous: 'Vorherige',
    Next: 'N&auml;chste',
    Last: 'Letzte',
    Page: 'Seite',
    FirstPageTooltip: 'Erste Seite',
    PreviousPageTooltip: 'Vorherige Seite',
    NextPageTooltip: 'N&auml;chste Seite',
    LastPageTooltip: 'Letzte Seite',
    Refresh: 'Aktualisieren',
    Of: 'von',
    DisplayingRecords: 'Zeige Datens&auml;tze',
    Edit: 'Editieren',
    Delete: 'L&ouml;schen',
    Update: '&Auml;ndern',
    Cancel: 'Abbrechen',
    NoRecordsFound: 'Es wurden keine Datens&auml;tze gefunden.'
};